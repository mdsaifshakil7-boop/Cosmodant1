import { Link } from "@tanstack/react-router";
import { MessageCircle, CalendarHeart } from "lucide-react";
import { CLINIC } from "@/lib/clinic";

export function FloatingCTA() {
  return (
    <div className="fixed bottom-4 right-4 z-40 flex flex-col items-end gap-3">
      <a
        href={`https://wa.me/${CLINIC.whatsapp}`}
        target="_blank"
        rel="noreferrer"
        aria-label="WhatsApp"
        className="group grid h-14 w-14 place-items-center rounded-full bg-[#25D366] text-white shadow-[0_15px_40px_-10px_rgba(37,211,102,0.6)] hover-lift"
      >
        <MessageCircle className="h-6 w-6" />
      </a>
      <Link
        to="/appointment"
        className="inline-flex items-center gap-2 rounded-full btn-hero px-5 py-3 text-sm font-semibold"
      >
        <CalendarHeart className="h-4 w-4" />
        Book
      </Link>
    </div>
  );
}
