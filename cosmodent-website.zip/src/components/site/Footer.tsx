import { Link } from "@tanstack/react-router";
import { Sparkles, MapPin, Phone, Mail, Clock, Instagram, Facebook } from "lucide-react";
import { CLINIC } from "@/lib/clinic";

export function SiteFooter() {
  return (
    <footer className="relative mt-24">
      <div className="mx-auto max-w-7xl px-4 pb-10">
        <div className="glass rounded-3xl p-8 md:p-12">
          <div className="grid gap-10 md:grid-cols-4">
            <div>
              <div className="flex items-center gap-2">
                <span className="grid h-10 w-10 place-items-center rounded-xl bg-[image:var(--gradient-primary)] text-white">
                  <Sparkles className="h-5 w-5" />
                </span>
                <div>
                  <div className="font-display text-lg font-bold">Cosmodent</div>
                  <div className="text-[10px] uppercase tracking-[0.2em] text-muted-foreground">
                    Aesthetic Clinic
                  </div>
                </div>
              </div>
              <p className="mt-4 text-sm text-muted-foreground">
                A premium destination for skin, hair, laser, aesthetic and dental care in Kolkata.
              </p>
              <div className="mt-4 flex gap-2">
                <a aria-label="Instagram" href="#" className="grid h-9 w-9 place-items-center rounded-full bg-white/70 hover:bg-white">
                  <Instagram className="h-4 w-4" />
                </a>
                <a aria-label="Facebook" href="#" className="grid h-9 w-9 place-items-center rounded-full bg-white/70 hover:bg-white">
                  <Facebook className="h-4 w-4" />
                </a>
              </div>
            </div>

            <div>
              <h4 className="text-sm font-semibold uppercase tracking-wider">Explore</h4>
              <ul className="mt-4 space-y-2 text-sm">
                <li><Link to="/about" className="hover:text-primary">About</Link></li>
                <li><Link to="/services" className="hover:text-primary">Services</Link></li>
                <li><Link to="/doctors" className="hover:text-primary">Doctors</Link></li>
                <li><Link to="/results" className="hover:text-primary">Results</Link></li>
                <li><Link to="/gallery" className="hover:text-primary">Gallery</Link></li>
              </ul>
            </div>

            <div>
              <h4 className="text-sm font-semibold uppercase tracking-wider">Visit</h4>
              <ul className="mt-4 space-y-3 text-sm text-muted-foreground">
                <li className="flex gap-2"><MapPin className="h-4 w-4 mt-0.5 shrink-0 text-primary" />{CLINIC.address}</li>
                <li className="flex gap-2"><Phone className="h-4 w-4 mt-0.5 shrink-0 text-primary" />
                  <a href={`tel:${CLINIC.phoneRaw}`}>{CLINIC.phone}</a>
                </li>
                <li className="flex gap-2"><Mail className="h-4 w-4 mt-0.5 shrink-0 text-primary" />{CLINIC.email}</li>
                <li className="flex gap-2"><Clock className="h-4 w-4 mt-0.5 shrink-0 text-primary" />{CLINIC.hours}</li>
              </ul>
            </div>

            <div>
              <h4 className="text-sm font-semibold uppercase tracking-wider">Book a Visit</h4>
              <p className="mt-4 text-sm text-muted-foreground">
                Reserve your consultation with Dr. Sourjya Ghosh.
              </p>
              <Link
                to="/appointment"
                className="mt-4 inline-flex items-center rounded-full btn-hero px-5 py-2.5 text-sm font-semibold"
              >
                Book Appointment
              </Link>
            </div>
          </div>

          <div className="mt-10 flex flex-col gap-2 border-t border-white/40 pt-6 text-xs text-muted-foreground sm:flex-row sm:justify-between">
            <p>© {new Date().getFullYear()} Cosmodent Aesthetic Clinic. All rights reserved.</p>
            <p>Designed for radiant confidence.</p>
          </div>
        </div>
      </div>
    </footer>
  );
}
