export const CLINIC = {
  name: "Cosmodent Aesthetic Clinic",
  doctor: "Dr. Sourjya Ghosh",
  phone: "+91 98304 42017",
  phoneRaw: "+919830442017",
  whatsapp: "919830442017",
  email: "care@cosmodentclinic.in",
  address: "86, Manohar Pukur Rd, Manoharpukur, Kalighat, Kolkata, West Bengal 700029",
  hours: "Mon–Sat: 10:00 AM – 8:00 PM",
  mapsQuery: "Cosmodent+Aesthetic+Clinic+Manohar+Pukur+Rd+Kalighat+Kolkata+700029",
} as const;
