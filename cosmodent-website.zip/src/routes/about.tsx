import { createFileRoute, Link } from "@tanstack/react-router";
import { Section, PageHero } from "@/components/site/Section";
import { Heart, Microscope, Sparkles, ShieldCheck } from "lucide-react";
import doctorImg from "@/assets/doctor.jpg";
import receptionImg from "@/assets/reception.jpg";
import treatmentImg from "@/assets/treatment-room.jpg";
import laserImg from "@/assets/laser.jpg";

export const Route = createFileRoute("/about")({
  head: () => ({
    meta: [
      { title: "About — Cosmodent Aesthetic Clinic, Kolkata" },
      { name: "description", content: "Discover Cosmodent's story, mission and the technology behind our luxury dermatology & aesthetic clinic in Kalighat, Kolkata." },
      { property: "og:title", content: "About Cosmodent Aesthetic Clinic" },
      { property: "og:url", content: "/about" },
    ],
    links: [{ rel: "canonical", href: "/about" }],
  }),
  component: AboutPage,
});

function AboutPage() {
  return (
    <>
      <PageHero eyebrow="About Us" title="Where science meets serenity" subtitle="A modern sanctuary for skin, hair and aesthetic excellence — designed around you." />

      <Section>
        <div className="grid gap-10 lg:grid-cols-2 lg:items-center">
          <div className="glass rounded-3xl p-3 hover-lift">
            <img src={receptionImg} alt="Clinic reception" className="aspect-[4/3] w-full rounded-2xl object-cover" loading="lazy" />
          </div>
          <div>
            <h2 className="font-display text-4xl font-bold">Our story</h2>
            <p className="mt-4 text-muted-foreground">
              Founded by Dr. Sourjya Ghosh, Cosmodent Aesthetic Clinic was born from a simple idea —
              that medical excellence and quiet luxury belong together. Tucked away on Manohar Pukur Road,
              our clinic is a calm, light-filled space where every protocol is honest, every result feels personal.
            </p>
            <p className="mt-4 text-muted-foreground">
              From everyday skincare to advanced laser & aesthetic procedures, we treat thousands of patients each
              year with USFDA-approved technology and hand-crafted care plans.
            </p>
          </div>
        </div>
      </Section>

      <Section>
        <div className="grid gap-6 md:grid-cols-3">
          {[
            { icon: Heart, title: "Mission", text: "Help every patient feel radiantly confident — through honest dermatology and refined aesthetics." },
            { icon: Sparkles, title: "Vision", text: "To be eastern India's most trusted name for ethical skin, hair & aesthetic care." },
            { icon: ShieldCheck, title: "Promise", text: "No upselling, no shortcuts. Just evidence-based protocols delivered with warmth." },
          ].map((c) => (
            <div key={c.title} className="glass rounded-3xl p-6 hover-lift">
              <span className="grid h-12 w-12 place-items-center rounded-2xl bg-[image:var(--gradient-primary)] text-white">
                <c.icon className="h-5 w-5" />
              </span>
              <h3 className="mt-4 font-display text-xl font-bold">{c.title}</h3>
              <p className="mt-2 text-sm text-muted-foreground">{c.text}</p>
            </div>
          ))}
        </div>
      </Section>

      <Section eyebrow="Why choose us" title="Crafted around your comfort">
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {[
            { title: "Board-certified care", desc: "Treatments led by qualified dermatologists." },
            { title: "USFDA-approved tech", desc: "Latest lasers, RF & energy-based devices." },
            { title: "Personalised plans", desc: "Every regimen tailored to your skin type." },
            { title: "Privacy-first", desc: "Discreet rooms and confidential records." },
          ].map((f) => (
            <div key={f.title} className="glass rounded-3xl p-5">
              <h4 className="font-display text-lg font-bold">{f.title}</h4>
              <p className="mt-2 text-sm text-muted-foreground">{f.desc}</p>
            </div>
          ))}
        </div>
      </Section>

      <Section eyebrow="Technology" title="Tools of transformation" subtitle="A curated suite of medical-grade devices we use everyday.">
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {[
            "Q-Switch Nd:YAG Laser",
            "Diode Laser Hair Removal",
            "Fractional CO₂ Laser",
            "HydraFacial™ MD",
            "Microneedling RF",
            "Cryolipolysis",
          ].map((t) => (
            <div key={t} className="glass rounded-2xl p-5 flex items-center gap-3 hover-lift">
              <Microscope className="h-5 w-5 text-primary" />
              <span className="font-medium">{t}</span>
            </div>
          ))}
        </div>
      </Section>

      <Section eyebrow="Meet the doctor">
        <div className="grid gap-10 lg:grid-cols-2 lg:items-center">
          <div className="glass rounded-3xl p-3 hover-lift">
            <img src={doctorImg} alt="Dr. Sourjya Ghosh" className="aspect-[4/5] w-full rounded-2xl object-cover" loading="lazy" />
          </div>
          <div>
            <h3 className="font-display text-3xl font-bold">Dr. Sourjya Ghosh</h3>
            <p className="mt-2 text-sm uppercase tracking-[0.2em] text-primary">MBBS · MD · Aesthetic Medicine</p>
            <p className="mt-4 text-muted-foreground">
              Renowned for an artistic, conservative approach to aesthetic medicine, Dr. Ghosh has helped thousands
              of patients restore confidence with results that look effortlessly natural.
            </p>
            <Link to="/doctors" className="mt-6 inline-flex rounded-full btn-hero px-5 py-2.5 text-sm font-semibold">
              View full profile
            </Link>
          </div>
        </div>
      </Section>

      <Section eyebrow="Inside the clinic">
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {[receptionImg, treatmentImg, laserImg, treatmentImg, receptionImg, laserImg].map((src, i) => (
            <div key={i} className="glass overflow-hidden rounded-3xl p-2 hover-lift">
              <img src={src} alt="Clinic" className="aspect-[4/3] w-full rounded-2xl object-cover" loading="lazy" />
            </div>
          ))}
        </div>
      </Section>
    </>
  );
}
