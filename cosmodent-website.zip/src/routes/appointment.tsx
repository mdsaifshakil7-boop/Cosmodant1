import { createFileRoute } from "@tanstack/react-router";
import { Section, PageHero } from "@/components/site/Section";
import { useState } from "react";
import { Calendar, Check } from "lucide-react";
import { CLINIC } from "@/lib/clinic";

export const Route = createFileRoute("/appointment")({
  head: () => ({
    meta: [
      { title: "Book Appointment — Cosmodent Aesthetic Clinic" },
      { name: "description", content: "Book your consultation with Dr. Sourjya Ghosh at Cosmodent Aesthetic Clinic, Kolkata. Skin, hair, laser & aesthetic treatments." },
      { property: "og:title", content: "Book Appointment | Cosmodent" },
      { property: "og:url", content: "/appointment" },
    ],
    links: [{ rel: "canonical", href: "/appointment" }],
  }),
  component: AppointmentPage,
});

const treatments = [
  "Skin consultation", "Acne treatment", "Pigmentation", "Anti-aging", "Hair fall / PRP",
  "Laser hair removal", "Tattoo removal", "Botox", "Fillers", "Hydra facial", "Carbon facial", "Other",
];

function AppointmentPage() {
  const [submitted, setSubmitted] = useState(false);
  const [form, setForm] = useState({ name: "", phone: "", email: "", treatment: "", doctor: CLINIC.doctor, date: "", time: "", message: "" });

  function update<K extends keyof typeof form>(k: K, v: string) {
    setForm((f) => ({ ...f, [k]: v }));
  }

  function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!form.name.trim() || !form.phone.trim()) return;
    setSubmitted(true);
  }

  return (
    <>
      <PageHero eyebrow="Book Appointment" title="Reserve your visit" subtitle="Fill in your details — our team will confirm your slot within minutes." />

      <Section>
        <div className="grid gap-8 lg:grid-cols-[1.6fr_1fr]">
          <div className="glass rounded-3xl p-6 sm:p-8">
            {submitted ? (
              <div className="py-12 text-center">
                <span className="mx-auto grid h-16 w-16 place-items-center rounded-full bg-[image:var(--gradient-primary)] text-white">
                  <Check className="h-7 w-7" />
                </span>
                <h3 className="mt-6 font-display text-3xl font-bold">Thank you, {form.name.split(" ")[0]}!</h3>
                <p className="mt-2 text-muted-foreground">We've received your appointment request. Our team will call you on {form.phone} shortly.</p>
              </div>
            ) : (
              <form onSubmit={onSubmit} className="grid gap-4 sm:grid-cols-2">
                <Field label="Full Name" required>
                  <input required value={form.name} maxLength={100} onChange={(e) => update("name", e.target.value)} className={inputCls} placeholder="Your name" />
                </Field>
                <Field label="Phone Number" required>
                  <input required type="tel" value={form.phone} maxLength={20} onChange={(e) => update("phone", e.target.value)} className={inputCls} placeholder="+91 ..." />
                </Field>
                <Field label="Email">
                  <input type="email" value={form.email} maxLength={120} onChange={(e) => update("email", e.target.value)} className={inputCls} placeholder="you@email.com" />
                </Field>
                <Field label="Treatment Type">
                  <select value={form.treatment} onChange={(e) => update("treatment", e.target.value)} className={inputCls}>
                    <option value="">Select treatment</option>
                    {treatments.map((t) => <option key={t} value={t}>{t}</option>)}
                  </select>
                </Field>
                <Field label="Doctor">
                  <select value={form.doctor} onChange={(e) => update("doctor", e.target.value)} className={inputCls}>
                    <option>{CLINIC.doctor}</option>
                  </select>
                </Field>
                <Field label="Preferred Date">
                  <input type="date" value={form.date} onChange={(e) => update("date", e.target.value)} className={inputCls} />
                </Field>
                <Field label="Preferred Time">
                  <input type="time" value={form.time} onChange={(e) => update("time", e.target.value)} className={inputCls} />
                </Field>
                <div className="sm:col-span-2">
                  <Field label="Message">
                    <textarea value={form.message} maxLength={500} rows={4} onChange={(e) => update("message", e.target.value)} className={inputCls} placeholder="Tell us about your concern..." />
                  </Field>
                </div>
                <div className="sm:col-span-2">
                  <button type="submit" className="w-full rounded-full btn-hero px-6 py-4 text-sm font-bold uppercase tracking-wider">
                    Book Appointment
                  </button>
                  <p className="mt-3 text-center text-xs text-muted-foreground">By submitting, you agree to be contacted by our team.</p>
                </div>
              </form>
            )}
          </div>

          <aside className="space-y-4">
            <div className="glass rounded-3xl p-6">
              <Calendar className="h-6 w-6 text-primary" />
              <h3 className="mt-3 font-display text-xl font-bold">Consultation timings</h3>
              <p className="mt-2 text-sm text-muted-foreground">{CLINIC.hours}</p>
            </div>
            <div className="glass rounded-3xl p-6">
              <h3 className="font-display text-xl font-bold">Prefer to talk?</h3>
              <a href={`tel:${CLINIC.phoneRaw}`} className="mt-3 block text-lg font-semibold gradient-text">{CLINIC.phone}</a>
              <a href={`https://wa.me/${CLINIC.whatsapp}`} target="_blank" rel="noreferrer" className="mt-4 inline-flex w-full items-center justify-center rounded-full bg-[#25D366] px-5 py-2.5 text-sm font-semibold text-white">
                WhatsApp Us
              </a>
            </div>
            <div className="glass rounded-3xl p-6">
              <h3 className="font-display text-xl font-bold">Address</h3>
              <p className="mt-2 text-sm text-muted-foreground">{CLINIC.address}</p>
            </div>
          </aside>
        </div>
      </Section>
    </>
  );
}

const inputCls =
  "w-full rounded-2xl border border-white/60 bg-white/70 px-4 py-3 text-sm outline-none transition focus:border-primary focus:bg-white focus:ring-4 focus:ring-primary/15";

function Field({ label, children, required }: { label: string; children: React.ReactNode; required?: boolean }) {
  return (
    <label className="block">
      <span className="mb-1.5 block text-xs font-semibold uppercase tracking-wider text-muted-foreground">
        {label}{required && <span className="text-primary"> *</span>}
      </span>
      {children}
    </label>
  );
}
