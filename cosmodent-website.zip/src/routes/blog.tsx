import { createFileRoute } from "@tanstack/react-router";
import { Section, PageHero } from "@/components/site/Section";
import { ArrowRight, Calendar } from "lucide-react";
import skinImg from "@/assets/skin-glow.jpg";
import hairImg from "@/assets/hair.jpg";
import laserImg from "@/assets/laser.jpg";
import aestheticImg from "@/assets/aesthetic.jpg";
import treatmentImg from "@/assets/treatment-room.jpg";
import receptionImg from "@/assets/reception.jpg";

export const Route = createFileRoute("/blog")({
  head: () => ({
    meta: [
      { title: "Blog — Skincare & Hair Care Guides | Cosmodent" },
      { name: "description", content: "Expert skincare, hair care and aesthetic medicine guides from Dr. Sourjya Ghosh and the Cosmodent team." },
      { property: "og:title", content: "Blog | Cosmodent" },
      { property: "og:url", content: "/blog" },
    ],
    links: [{ rel: "canonical", href: "/blog" }],
  }),
  component: BlogPage,
});

const posts = [
  { title: "5 dermatologist-approved tips for glowing skin", img: skinImg, cat: "Skin Care", date: "Jun 2026" },
  { title: "Is PRP therapy right for your hair fall?", img: hairImg, cat: "Hair Care", date: "May 2026" },
  { title: "Laser hair removal: what to expect", img: laserImg, cat: "Treatment Guide", date: "May 2026" },
  { title: "Botox & fillers — natural beauty, demystified", img: aestheticImg, cat: "Aesthetic", date: "Apr 2026" },
  { title: "Monsoon skincare: a 5-step routine", img: treatmentImg, cat: "Seasonal", date: "Apr 2026" },
  { title: "How to choose the right hydra facial for you", img: receptionImg, cat: "Treatment Guide", date: "Mar 2026" },
];

function BlogPage() {
  return (
    <>
      <PageHero eyebrow="Blog" title="Skincare wisdom, distilled" subtitle="Expert insights, seasonal routines and treatment guides." />

      <Section>
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {posts.map((p, i) => (
            <article key={i} className="group glass overflow-hidden rounded-3xl p-3 hover-lift">
              <div className="overflow-hidden rounded-2xl">
                <img src={p.img} alt={p.title} className="aspect-[4/3] w-full object-cover transition-transform duration-700 group-hover:scale-105" loading="lazy" />
              </div>
              <div className="p-4">
                <div className="flex items-center justify-between text-xs">
                  <span className="rounded-full bg-white/70 px-3 py-1 font-semibold text-primary">{p.cat}</span>
                  <span className="flex items-center gap-1 text-muted-foreground"><Calendar className="h-3 w-3" />{p.date}</span>
                </div>
                <h3 className="mt-3 font-display text-lg font-bold leading-snug">{p.title}</h3>
                <span className="mt-3 inline-flex items-center gap-1 text-sm font-semibold text-primary">
                  Read more <ArrowRight className="h-3.5 w-3.5 transition-transform group-hover:translate-x-1" />
                </span>
              </div>
            </article>
          ))}
        </div>
      </Section>
    </>
  );
}
