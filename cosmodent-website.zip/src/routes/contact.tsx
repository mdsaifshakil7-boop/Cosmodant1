import { createFileRoute } from "@tanstack/react-router";
import { Section, PageHero } from "@/components/site/Section";
import { MapPin, Phone, Mail, Clock, MessageCircle } from "lucide-react";
import { CLINIC } from "@/lib/clinic";

export const Route = createFileRoute("/contact")({
  head: () => ({
    meta: [
      { title: "Contact Cosmodent Aesthetic Clinic — Kalighat, Kolkata" },
      { name: "description", content: "Visit Cosmodent at 86 Manohar Pukur Rd, Kalighat, Kolkata 700029. Call +91 98304 42017 or WhatsApp us today." },
      { property: "og:title", content: "Contact | Cosmodent" },
      { property: "og:url", content: "/contact" },
    ],
    links: [{ rel: "canonical", href: "/contact" }],
  }),
  component: ContactPage,
});

function ContactPage() {
  return (
    <>
      <PageHero eyebrow="Contact" title="Come say hello" subtitle="Visit, call or WhatsApp us — we'd love to meet you." />

      <Section>
        <div className="grid gap-6 lg:grid-cols-[1fr_1.4fr]">
          <div className="space-y-4">
            <Card icon={MapPin} title="Address">{CLINIC.address}</Card>
            <Card icon={Phone} title="Phone">
              <a href={`tel:${CLINIC.phoneRaw}`} className="font-semibold gradient-text">{CLINIC.phone}</a>
            </Card>
            <Card icon={MessageCircle} title="WhatsApp">
              <a href={`https://wa.me/${CLINIC.whatsapp}`} target="_blank" rel="noreferrer" className="font-semibold gradient-text">Chat with us instantly</a>
            </Card>
            <Card icon={Mail} title="Email">{CLINIC.email}</Card>
            <Card icon={Clock} title="Working hours">{CLINIC.hours}</Card>
          </div>

          <div className="glass overflow-hidden rounded-3xl p-2">
            <iframe
              title="Cosmodent location map"
              src={`https://www.google.com/maps?q=${CLINIC.mapsQuery}&output=embed`}
              loading="lazy"
              className="h-[500px] w-full rounded-2xl"
              referrerPolicy="no-referrer-when-downgrade"
            />
          </div>
        </div>
      </Section>
    </>
  );
}

function Card({ icon: Icon, title, children }: { icon: any; title: string; children: React.ReactNode }) {
  return (
    <div className="glass rounded-3xl p-6 hover-lift">
      <div className="flex items-center gap-3">
        <span className="grid h-10 w-10 place-items-center rounded-xl bg-[image:var(--gradient-primary)] text-white">
          <Icon className="h-4 w-4" />
        </span>
        <h3 className="font-display text-lg font-bold">{title}</h3>
      </div>
      <div className="mt-3 text-sm text-muted-foreground">{children}</div>
    </div>
  );
}
