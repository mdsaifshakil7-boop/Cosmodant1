import { createFileRoute, Link } from "@tanstack/react-router";
import { Section, PageHero } from "@/components/site/Section";
import { Award, Clock, GraduationCap, Star } from "lucide-react";
import doctorImg from "@/assets/doctor.jpg";
import { CLINIC } from "@/lib/clinic";

export const Route = createFileRoute("/doctors")({
  head: () => ({
    meta: [
      { title: "Dr. Sourjya Ghosh — Dermatologist & Aesthetic Physician" },
      { name: "description", content: "Meet Dr. Sourjya Ghosh — Founder, Cosmodent Aesthetic Clinic, Kolkata. MBBS, MD with 15+ years of experience in dermatology & aesthetic medicine." },
      { property: "og:title", content: "Dr. Sourjya Ghosh | Cosmodent" },
      { property: "og:url", content: "/doctors" },
    ],
    links: [{ rel: "canonical", href: "/doctors" }],
  }),
  component: DoctorsPage,
});

function DoctorsPage() {
  return (
    <>
      <PageHero eyebrow="Our Doctors" title="Care led by experts" subtitle="Meet the practitioner crafting your transformation." />

      <Section>
        <div className="glass rounded-3xl p-4 sm:p-8 hover-lift">
          <div className="grid gap-8 lg:grid-cols-[minmax(0,1fr)_minmax(0,1.3fr)] lg:items-center">
            <div className="overflow-hidden rounded-2xl">
              <img src={doctorImg} alt={CLINIC.doctor} className="aspect-[4/5] w-full object-cover" loading="lazy" />
            </div>
            <div>
              <span className="inline-block rounded-full bg-white/70 px-4 py-1 text-xs font-semibold uppercase tracking-[0.2em] text-primary">Founder & Chief Dermatologist</span>
              <h2 className="mt-4 font-display text-4xl font-bold sm:text-5xl">{CLINIC.doctor}</h2>
              <div className="mt-3 flex items-center gap-1 text-sm">
                {[...Array(5)].map((_, i) => <Star key={i} className="h-4 w-4 fill-yellow-400 text-yellow-400" />)}
                <span className="ml-2 text-muted-foreground">4.9 ★ from 1,200+ reviews</span>
              </div>

              <div className="mt-8 grid gap-4 sm:grid-cols-2">
                <div className="rounded-2xl bg-white/60 p-4">
                  <div className="flex items-center gap-2 text-sm font-semibold"><GraduationCap className="h-4 w-4 text-primary" /> Qualification</div>
                  <p className="mt-1 text-sm text-muted-foreground">MBBS · MD Dermatology · Aesthetic Medicine (Fellowship)</p>
                </div>
                <div className="rounded-2xl bg-white/60 p-4">
                  <div className="flex items-center gap-2 text-sm font-semibold"><Award className="h-4 w-4 text-primary" /> Experience</div>
                  <p className="mt-1 text-sm text-muted-foreground">15+ years across leading dermatology centres</p>
                </div>
                <div className="rounded-2xl bg-white/60 p-4">
                  <div className="flex items-center gap-2 text-sm font-semibold"><Star className="h-4 w-4 text-primary" /> Specialisation</div>
                  <p className="mt-1 text-sm text-muted-foreground">Acne · Pigmentation · Anti-aging · Lasers · Botox & Fillers</p>
                </div>
                <div className="rounded-2xl bg-white/60 p-4">
                  <div className="flex items-center gap-2 text-sm font-semibold"><Clock className="h-4 w-4 text-primary" /> Consultation</div>
                  <p className="mt-1 text-sm text-muted-foreground">Mon–Sat · 10:00 AM – 8:00 PM</p>
                </div>
              </div>

              <p className="mt-6 text-muted-foreground">
                Dr. Ghosh is known for an honest, conservative approach — never overpromising, always over-delivering.
                He has trained under leading aesthetic physicians and lectures regularly on safe injectable practice.
              </p>

              <div className="mt-8 flex flex-wrap gap-3">
                <Link to="/appointment" className="rounded-full btn-hero px-6 py-3 text-sm font-semibold">Book Appointment</Link>
                <a href={`tel:${CLINIC.phoneRaw}`} className="rounded-full glass px-6 py-3 text-sm font-semibold">{CLINIC.phone}</a>
              </div>
            </div>
          </div>
        </div>
      </Section>
    </>
  );
}
