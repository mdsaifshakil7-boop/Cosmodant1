import { createFileRoute, Link } from "@tanstack/react-router";
import { Section, PageHero } from "@/components/site/Section";
import { useState } from "react";
import { Plus, Minus } from "lucide-react";

export const Route = createFileRoute("/faq")({
  head: () => ({
    meta: [
      { title: "FAQs — Cosmodent Aesthetic Clinic" },
      { name: "description", content: "Common questions about treatments, pricing, safety, side effects and appointments at Cosmodent Aesthetic Clinic, Kolkata." },
      { property: "og:title", content: "FAQs | Cosmodent" },
      { property: "og:url", content: "/faq" },
    ],
    links: [{ rel: "canonical", href: "/faq" }],
    scripts: [{
      type: "application/ld+json",
      children: JSON.stringify({
        "@context": "https://schema.org",
        "@type": "FAQPage",
        mainEntity: faqs.map((f) => ({
          "@type": "Question", name: f.q,
          acceptedAnswer: { "@type": "Answer", text: f.a },
        })),
      }),
    }],
  }),
  component: FaqPage,
});

const faqs = [
  { q: "Are your treatments safe?", a: "Yes. Every treatment is performed by qualified dermatologists using USFDA-approved equipment, with strict hygiene and consent protocols." },
  { q: "How are treatments priced?", a: "Pricing depends on your skin condition, treatment type and number of sessions. Your free consultation includes a transparent, written quote — no surprises." },
  { q: "How long does each session take?", a: "Most sessions take 30–60 minutes. Quick treatments like Botox can finish in 15 minutes; intensive procedures may run up to 90 minutes." },
  { q: "Are there any side effects?", a: "Mild redness or sensitivity is common for 24–48 hours. Serious side effects are rare when treatments are performed by trained professionals — we walk you through every possibility before starting." },
  { q: "How do I book an appointment?", a: "Use our online appointment form, call +91 98304 42017, or message us on WhatsApp. We confirm slots within minutes during working hours." },
  { q: "Do you offer follow-up care?", a: "Yes. Every protocol includes complimentary follow-up consultations to track your progress and adjust the plan if needed." },
];

function FaqPage() {
  const [open, setOpen] = useState<number | null>(0);
  return (
    <>
      <PageHero eyebrow="FAQs" title="Questions, answered" subtitle="Everything you'd like to know before booking." />
      <Section>
        <div className="mx-auto max-w-3xl">
          <div className="glass rounded-3xl p-3">
            {faqs.map((f, i) => {
              const isOpen = open === i;
              return (
                <div key={i} className="border-b border-white/40 last:border-b-0">
                  <button onClick={() => setOpen(isOpen ? null : i)} className="flex w-full items-center justify-between gap-4 p-5 text-left">
                    <span className="font-display text-lg font-bold">{f.q}</span>
                    <span className="grid h-9 w-9 shrink-0 place-items-center rounded-full bg-[image:var(--gradient-primary)] text-white">
                      {isOpen ? <Minus className="h-4 w-4" /> : <Plus className="h-4 w-4" />}
                    </span>
                  </button>
                  {isOpen && <div className="px-5 pb-5 text-muted-foreground animate-fade-in">{f.a}</div>}
                </div>
              );
            })}
          </div>
          <div className="mt-10 text-center">
            <p className="text-muted-foreground">Still have questions?</p>
            <Link to="/contact" className="mt-3 inline-flex rounded-full btn-hero px-5 py-2.5 text-sm font-semibold">Contact us</Link>
          </div>
        </div>
      </Section>
    </>
  );
}
