import { createFileRoute } from "@tanstack/react-router";
import { Section, PageHero } from "@/components/site/Section";
import { useState } from "react";
import { X } from "lucide-react";
import receptionImg from "@/assets/reception.jpg";
import treatmentImg from "@/assets/treatment-room.jpg";
import laserImg from "@/assets/laser.jpg";
import aestheticImg from "@/assets/aesthetic.jpg";
import doctorImg from "@/assets/doctor.jpg";
import skinImg from "@/assets/skin-glow.jpg";
import hairImg from "@/assets/hair.jpg";
import heroImg from "@/assets/hero-clinic.jpg";

export const Route = createFileRoute("/gallery")({
  head: () => ({
    meta: [
      { title: "Gallery — Inside Cosmodent Aesthetic Clinic" },
      { name: "description", content: "Take a visual tour of Cosmodent — our reception, treatment rooms, laser machines and patient care." },
      { property: "og:title", content: "Gallery | Cosmodent" },
      { property: "og:url", content: "/gallery" },
    ],
    links: [{ rel: "canonical", href: "/gallery" }],
  }),
  component: GalleryPage,
});

const photos = [
  { src: receptionImg, label: "Reception" },
  { src: treatmentImg, label: "Treatment Room" },
  { src: laserImg, label: "Laser Machine" },
  { src: aestheticImg, label: "Aesthetic Care" },
  { src: doctorImg, label: "Consultation" },
  { src: heroImg, label: "Clinic Interior" },
  { src: skinImg, label: "Skin Care" },
  { src: hairImg, label: "Hair Care" },
];

function GalleryPage() {
  const [active, setActive] = useState<number | null>(null);

  return (
    <>
      <PageHero eyebrow="Gallery" title="A look inside" subtitle="Designed for calm. Built for results." />

      <Section>
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {photos.map((p, i) => (
            <button
              key={i}
              onClick={() => setActive(i)}
              className="group glass overflow-hidden rounded-3xl p-2 hover-lift text-left"
            >
              <div className="relative overflow-hidden rounded-2xl">
                <img src={p.src} alt={p.label} className="aspect-[4/3] w-full object-cover transition-transform duration-700 group-hover:scale-105" loading="lazy" />
                <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/60 to-transparent p-4">
                  <span className="text-sm font-semibold text-white">{p.label}</span>
                </div>
              </div>
            </button>
          ))}
        </div>
      </Section>

      {active !== null && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center bg-black/80 p-4 animate-fade-in" onClick={() => setActive(null)}>
          <button aria-label="Close" className="absolute right-4 top-4 grid h-12 w-12 place-items-center rounded-full bg-white/90 text-foreground" onClick={() => setActive(null)}>
            <X className="h-5 w-5" />
          </button>
          <img src={photos[active].src} alt={photos[active].label} className="max-h-[90vh] max-w-[95vw] rounded-2xl object-contain" />
        </div>
      )}
    </>
  );
}
