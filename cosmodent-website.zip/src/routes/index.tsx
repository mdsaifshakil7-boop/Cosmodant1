import { createFileRoute, Link } from "@tanstack/react-router";
import { Sparkles, Star, Phone, MessageCircle, ArrowRight, ShieldCheck, Award, Users, Clock, Quote } from "lucide-react";
import heroImg from "@/assets/hero-clinic.jpg";
import doctorImg from "@/assets/doctor.jpg";
import skinImg from "@/assets/skin-glow.jpg";
import hairImg from "@/assets/hair.jpg";
import laserImg from "@/assets/laser.jpg";
import aestheticImg from "@/assets/aesthetic.jpg";
import { CLINIC } from "@/lib/clinic";
import { Section } from "@/components/site/Section";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Cosmodent Aesthetic Clinic — Glow With Confidence | Kolkata" },
      { name: "description", content: "Luxury skin, hair, laser, aesthetic & dental treatments by Dr. Sourjya Ghosh. Book your consultation at Cosmodent Aesthetic Clinic, Kalighat, Kolkata." },
      { property: "og:title", content: "Cosmodent Aesthetic Clinic — Glow With Confidence" },
      { property: "og:description", content: "Premium dermatology & aesthetic care in Kolkata." },
      { property: "og:url", content: "/" },
    ],
    links: [{ rel: "canonical", href: "/" }],
  }),
  component: HomePage,
});

const services = [
  { title: "Skin Care", desc: "Acne, pigmentation, anti-aging & glow treatments.", img: skinImg },
  { title: "Hair Care", desc: "PRP, regrowth, hair fall & scalp therapy.", img: hairImg },
  { title: "Laser", desc: "Hair removal, tattoo removal & rejuvenation.", img: laserImg },
  { title: "Aesthetic", desc: "Botox, fillers, thread lift & hydra facial.", img: aestheticImg },
];

const stats = [
  { icon: Users, value: "10,000+", label: "Happy Patients" },
  { icon: Award, value: "15+", label: "Years Experience" },
  { icon: Star, value: "4.9★", label: "Patient Rating" },
  { icon: ShieldCheck, value: "USFDA", label: "Approved Tech" },
];

const testimonials = [
  { name: "Ananya S.", text: "My skin has never looked better. The team is exceptional and the clinic feels like a five-star spa.", role: "Hydra Facial" },
  { name: "Rohit M.", text: "Dr. Ghosh's PRP plan transformed my hairline in months. Honest advice and great results.", role: "PRP Therapy" },
  { name: "Priya D.", text: "Painless laser sessions, world-class machines and warm staff. Highly recommended.", role: "Laser Hair Removal" },
];

function HomePage() {
  return (
    <>
      {/* HERO */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 -z-10">
          <img src={heroImg} alt="" className="h-full w-full object-cover opacity-50" />
          <div className="absolute inset-0 bg-gradient-to-b from-white/60 via-white/40 to-background" />
        </div>
        <div className="mx-auto max-w-7xl px-4 pt-12 pb-24 sm:pt-20 sm:pb-32">
          <div className="grid gap-10 lg:grid-cols-2 lg:items-center">
            <div className="animate-fade-in">
              <span className="inline-flex items-center gap-2 rounded-full glass px-4 py-1.5 text-xs font-semibold uppercase tracking-[0.2em] text-primary">
                <Sparkles className="h-3.5 w-3.5" /> Luxury Aesthetic Clinic · Kolkata
              </span>
              <h1 className="mt-6 font-display text-5xl font-bold leading-[1.05] tracking-tight sm:text-7xl">
                <span className="gradient-text">Glow With</span><br />
                <span>Confidence</span>
              </h1>
              <p className="mt-5 text-lg text-muted-foreground sm:text-xl">
                Skin · Hair · Laser · Aesthetic · Dental Care — crafted by{" "}
                <span className="font-semibold text-foreground">{CLINIC.doctor}</span>.
              </p>
              <div className="mt-8 flex flex-wrap gap-3">
                <Link to="/appointment" className="inline-flex items-center gap-2 rounded-full btn-hero px-6 py-3.5 text-sm font-semibold">
                  Book Appointment <ArrowRight className="h-4 w-4" />
                </Link>
                <a href={`https://wa.me/${CLINIC.whatsapp}`} target="_blank" rel="noreferrer" className="inline-flex items-center gap-2 rounded-full bg-[#25D366] px-6 py-3.5 text-sm font-semibold text-white hover-lift">
                  <MessageCircle className="h-4 w-4" /> WhatsApp
                </a>
                <a href={`tel:${CLINIC.phoneRaw}`} className="inline-flex items-center gap-2 rounded-full glass px-6 py-3.5 text-sm font-semibold">
                  <Phone className="h-4 w-4" /> Call Now
                </a>
              </div>
              <div className="mt-10 flex items-center gap-6 text-sm">
                <div className="flex">
                  {[...Array(5)].map((_, i) => <Star key={i} className="h-4 w-4 fill-yellow-400 text-yellow-400" />)}
                </div>
                <span className="text-muted-foreground"><b className="text-foreground">4.9</b> from 1,200+ Google reviews</span>
              </div>
            </div>

            <div className="relative">
              <div className="glass animate-float rounded-3xl p-3 hover-lift">
                <img src={heroImg} alt="Cosmodent Aesthetic Clinic interior" className="aspect-[4/5] w-full rounded-2xl object-cover" width={1920} height={1080} />
              </div>
              <div className="absolute -bottom-6 -left-6 glass rounded-2xl p-4 max-w-[220px] hidden sm:block">
                <div className="text-xs uppercase tracking-wider text-muted-foreground">Today's slots</div>
                <div className="mt-1 font-display text-2xl font-bold gradient-text">3 Available</div>
                <div className="mt-1 text-xs text-muted-foreground">Reserve before 6 PM</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* SERVICES PREVIEW */}
      <Section eyebrow="Signature Services" title="Treatments crafted for radiant you" subtitle="From medical-grade skincare to advanced lasers, every protocol is tailored to your skin's story.">
        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {services.map((s) => (
            <Link to="/services" key={s.title} className="group glass rounded-3xl p-3 hover-lift">
              <div className="overflow-hidden rounded-2xl">
                <img src={s.img} alt={s.title} className="aspect-square w-full object-cover transition-transform duration-700 group-hover:scale-105" loading="lazy" />
              </div>
              <div className="p-4">
                <h3 className="font-display text-xl font-bold">{s.title}</h3>
                <p className="mt-1 text-sm text-muted-foreground">{s.desc}</p>
                <span className="mt-3 inline-flex items-center gap-1 text-sm font-semibold text-primary">
                  Explore <ArrowRight className="h-3.5 w-3.5 transition-transform group-hover:translate-x-1" />
                </span>
              </div>
            </Link>
          ))}
        </div>
      </Section>

      {/* DOCTOR INTRO */}
      <Section eyebrow="Meet Your Doctor">
        <div className="grid gap-10 lg:grid-cols-2 lg:items-center">
          <div className="glass rounded-3xl p-3 hover-lift">
            <img src={doctorImg} alt={CLINIC.doctor} className="aspect-[4/5] w-full rounded-2xl object-cover" loading="lazy" />
          </div>
          <div>
            <h2 className="font-display text-4xl font-bold sm:text-5xl">{CLINIC.doctor}</h2>
            <p className="mt-2 text-sm uppercase tracking-[0.2em] text-primary">MBBS · MD Dermatology · Aesthetic Medicine</p>
            <p className="mt-6 text-lg text-muted-foreground">
              With over 15 years of experience, Dr. Ghosh blends scientific precision with an artistic eye —
              creating outcomes that look natural, refined and unmistakably you.
            </p>
            <ul className="mt-6 grid gap-3 sm:grid-cols-2">
              {["USFDA-grade equipment","Personalised protocols","Painless techniques","Confidential care"].map((p) => (
                <li key={p} className="flex items-center gap-2 text-sm">
                  <span className="grid h-6 w-6 place-items-center rounded-full bg-[image:var(--gradient-primary)] text-white">
                    <ShieldCheck className="h-3.5 w-3.5" />
                  </span>
                  {p}
                </li>
              ))}
            </ul>
            <div className="mt-8 flex gap-3">
              <Link to="/doctors" className="rounded-full glass px-5 py-2.5 text-sm font-semibold">View Profile</Link>
              <Link to="/appointment" className="rounded-full btn-hero px-5 py-2.5 text-sm font-semibold">Book Consultation</Link>
            </div>
          </div>
        </div>
      </Section>

      {/* TRUST */}
      <Section>
        <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
          {stats.map((s) => (
            <div key={s.label} className="glass rounded-3xl p-6 text-center hover-lift">
              <span className="mx-auto grid h-12 w-12 place-items-center rounded-2xl bg-[image:var(--gradient-primary)] text-white">
                <s.icon className="h-5 w-5" />
              </span>
              <div className="mt-4 font-display text-3xl font-bold gradient-text">{s.value}</div>
              <div className="mt-1 text-sm text-muted-foreground">{s.label}</div>
            </div>
          ))}
        </div>
      </Section>

      {/* BEFORE/AFTER PREVIEW */}
      <Section eyebrow="Real Results" title="Before & After" subtitle="A glimpse of transformations from our clinical archive.">
        <div className="grid gap-6 md:grid-cols-3">
          {[skinImg, aestheticImg, hairImg].map((img, i) => (
            <div key={i} className="glass overflow-hidden rounded-3xl p-3 hover-lift">
              <div className="grid grid-cols-2 gap-2">
                <div className="relative overflow-hidden rounded-2xl">
                  <img src={img} alt="Before" className="aspect-[3/4] w-full object-cover grayscale" loading="lazy" />
                  <span className="absolute left-2 top-2 rounded-full bg-black/60 px-2 py-0.5 text-[10px] font-semibold text-white">BEFORE</span>
                </div>
                <div className="relative overflow-hidden rounded-2xl">
                  <img src={img} alt="After" className="aspect-[3/4] w-full object-cover" loading="lazy" />
                  <span className="absolute left-2 top-2 rounded-full bg-[image:var(--gradient-primary)] px-2 py-0.5 text-[10px] font-semibold text-white">AFTER</span>
                </div>
              </div>
            </div>
          ))}
        </div>
        <div className="mt-8 text-center">
          <Link to="/results" className="inline-flex items-center gap-2 rounded-full glass px-5 py-2.5 text-sm font-semibold">
            View All Results <ArrowRight className="h-4 w-4" />
          </Link>
        </div>
      </Section>

      {/* TESTIMONIALS */}
      <Section eyebrow="Loved By Our Patients" title="What people say">
        <div className="grid gap-6 md:grid-cols-3">
          {testimonials.map((t) => (
            <div key={t.name} className="glass rounded-3xl p-6 hover-lift">
              <Quote className="h-7 w-7 text-primary" />
              <p className="mt-4 text-base">"{t.text}"</p>
              <div className="mt-6 flex items-center justify-between">
                <div>
                  <div className="font-semibold">{t.name}</div>
                  <div className="text-xs text-muted-foreground">{t.role}</div>
                </div>
                <div className="flex">
                  {[...Array(5)].map((_, i) => <Star key={i} className="h-3.5 w-3.5 fill-yellow-400 text-yellow-400" />)}
                </div>
              </div>
            </div>
          ))}
        </div>
      </Section>

      {/* GOOGLE REVIEWS */}
      <Section>
        <div className="glass rounded-3xl p-8 sm:p-12 text-center">
          <div className="mx-auto inline-flex items-center gap-2 rounded-full bg-white/70 px-4 py-1.5 text-xs font-semibold uppercase tracking-wider">
            <Star className="h-3.5 w-3.5 fill-yellow-400 text-yellow-400" /> Google Reviews
          </div>
          <div className="mt-6 font-display text-7xl font-bold gradient-text">4.9</div>
          <div className="mt-2 flex justify-center">
            {[...Array(5)].map((_, i) => <Star key={i} className="h-5 w-5 fill-yellow-400 text-yellow-400" />)}
          </div>
          <p className="mt-4 text-muted-foreground">Based on 1,200+ verified Google reviews</p>
          <Link to="/reviews" className="mt-6 inline-flex items-center gap-2 rounded-full btn-hero px-6 py-3 text-sm font-semibold">
            Read All Reviews <ArrowRight className="h-4 w-4" />
          </Link>
        </div>
      </Section>

      {/* CTA */}
      <Section>
        <div className="relative overflow-hidden rounded-3xl bg-[image:var(--gradient-hero)] p-8 text-center text-white sm:p-16 shadow-[var(--shadow-glow)]">
          <Clock className="mx-auto h-10 w-10 opacity-90" />
          <h2 className="mt-4 font-display text-4xl font-bold sm:text-5xl">Your glow is one call away</h2>
          <p className="mx-auto mt-4 max-w-xl text-white/90">Reserve a personalised consultation with {CLINIC.doctor} today.</p>
          <div className="mt-8 flex flex-wrap justify-center gap-3">
            <Link to="/appointment" className="rounded-full bg-white px-6 py-3 text-sm font-semibold text-primary hover-lift">Book Appointment</Link>
            <a href={`tel:${CLINIC.phoneRaw}`} className="rounded-full bg-white/15 backdrop-blur px-6 py-3 text-sm font-semibold ring-1 ring-white/30">
              {CLINIC.phone}
            </a>
          </div>
        </div>
      </Section>
    </>
  );
}
