import { createFileRoute, Link } from "@tanstack/react-router";
import { Section, PageHero } from "@/components/site/Section";
import skinImg from "@/assets/skin-glow.jpg";
import hairImg from "@/assets/hair.jpg";
import laserImg from "@/assets/laser.jpg";
import aestheticImg from "@/assets/aesthetic.jpg";

export const Route = createFileRoute("/results")({
  head: () => ({
    meta: [
      { title: "Before & After Results — Cosmodent Aesthetic Clinic" },
      { name: "description", content: "Real before & after transformations from Cosmodent — acne, pigmentation, hair regrowth, laser & skin rejuvenation results." },
      { property: "og:title", content: "Results | Cosmodent" },
      { property: "og:url", content: "/results" },
    ],
    links: [{ rel: "canonical", href: "/results" }],
  }),
  component: ResultsPage,
});

const cases = [
  { title: "Acne & Scar Reduction", img: skinImg, weeks: "12 weeks" },
  { title: "Hair Regrowth (PRP)", img: hairImg, weeks: "6 sessions" },
  { title: "Laser Hair Removal", img: laserImg, weeks: "8 sessions" },
  { title: "Skin Rejuvenation", img: aestheticImg, weeks: "10 weeks" },
  { title: "Pigmentation Repair", img: skinImg, weeks: "16 weeks" },
  { title: "Anti-aging Lift", img: aestheticImg, weeks: "12 weeks" },
];

function ResultsPage() {
  return (
    <>
      <PageHero eyebrow="Real Results" title="Transformations that speak" subtitle="Documented patient outcomes — shared with consent." />

      <Section>
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {cases.map((c, i) => (
            <div key={i} className="glass rounded-3xl p-3 hover-lift">
              <div className="grid grid-cols-2 gap-2">
                <div className="relative overflow-hidden rounded-2xl">
                  <img src={c.img} alt="Before" className="aspect-[3/4] w-full object-cover grayscale" loading="lazy" />
                  <span className="absolute left-2 top-2 rounded-full bg-black/60 px-2 py-0.5 text-[10px] font-semibold text-white">BEFORE</span>
                </div>
                <div className="relative overflow-hidden rounded-2xl">
                  <img src={c.img} alt="After" className="aspect-[3/4] w-full object-cover" loading="lazy" />
                  <span className="absolute left-2 top-2 rounded-full bg-[image:var(--gradient-primary)] px-2 py-0.5 text-[10px] font-semibold text-white">AFTER</span>
                </div>
              </div>
              <div className="flex items-center justify-between p-3">
                <h3 className="font-display text-lg font-bold">{c.title}</h3>
                <span className="text-xs text-muted-foreground">{c.weeks}</span>
              </div>
            </div>
          ))}
        </div>
      </Section>

      <Section>
        <div className="glass rounded-3xl p-8 text-center sm:p-12">
          <h3 className="font-display text-3xl font-bold">Want results like these?</h3>
          <p className="mt-2 text-muted-foreground">Book a personalised consultation today.</p>
          <Link to="/appointment" className="mt-6 inline-flex rounded-full btn-hero px-6 py-3 text-sm font-semibold">
            Book Appointment
          </Link>
        </div>
      </Section>
    </>
  );
}
