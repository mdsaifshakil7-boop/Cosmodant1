import { createFileRoute } from "@tanstack/react-router";
import { Section, PageHero } from "@/components/site/Section";
import { Star, Quote, Play } from "lucide-react";

export const Route = createFileRoute("/reviews")({
  head: () => ({
    meta: [
      { title: "Reviews & Testimonials — Cosmodent Aesthetic Clinic" },
      { name: "description", content: "Read 1,200+ verified Google reviews and patient testimonials about Cosmodent Aesthetic Clinic and Dr. Sourjya Ghosh." },
      { property: "og:title", content: "Reviews | Cosmodent" },
      { property: "og:url", content: "/reviews" },
    ],
    links: [{ rel: "canonical", href: "/reviews" }],
  }),
  component: ReviewsPage,
});

const reviews = [
  { name: "Ananya Sen", text: "Best decision ever. The hydra facial gave me a glow I didn't think was possible. Loved the calm interiors too.", role: "Hydra Facial" },
  { name: "Rohit Mukherjee", text: "Dr. Ghosh's PRP plan transformed my hairline within months. Honest, science-backed advice.", role: "PRP Therapy" },
  { name: "Priya Das", text: "Painless laser sessions and warm staff. World-class machines without the overpriced fluff.", role: "Laser Hair Removal" },
  { name: "Ishaan Kapoor", text: "I came for acne — left with a permanent skincare routine. My skin looks 10 years younger.", role: "Acne Treatment" },
  { name: "Rhea Banerjee", text: "Subtle, natural-looking fillers. Dr. Ghosh truly understands proportion and balance.", role: "Fillers" },
  { name: "Meera Iyer", text: "Pigmentation gone after 4 sessions. The clinic feels like a luxury spa.", role: "Pigmentation" },
];

function ReviewsPage() {
  return (
    <>
      <PageHero eyebrow="Reviews" title="Loved by 10,000+ patients" subtitle="Real stories from real people." />

      <Section>
        <div className="glass rounded-3xl p-8 text-center sm:p-12">
          <div className="mx-auto inline-flex items-center gap-2 rounded-full bg-white/70 px-4 py-1.5 text-xs font-semibold uppercase tracking-wider">
            <Star className="h-3.5 w-3.5 fill-yellow-400 text-yellow-400" /> Google Reviews
          </div>
          <div className="mt-6 font-display text-7xl font-bold gradient-text">4.9</div>
          <div className="mt-2 flex justify-center">
            {[...Array(5)].map((_, i) => <Star key={i} className="h-5 w-5 fill-yellow-400 text-yellow-400" />)}
          </div>
          <p className="mt-4 text-muted-foreground">Based on 1,200+ verified reviews</p>
          <a href="#" className="mt-6 inline-flex rounded-full btn-hero px-6 py-3 text-sm font-semibold">Write a Review</a>
        </div>
      </Section>

      <Section eyebrow="Patient testimonials">
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {reviews.map((r) => (
            <div key={r.name} className="glass rounded-3xl p-6 hover-lift">
              <Quote className="h-7 w-7 text-primary" />
              <p className="mt-4 text-base">"{r.text}"</p>
              <div className="mt-6 flex items-center justify-between">
                <div>
                  <div className="font-semibold">{r.name}</div>
                  <div className="text-xs text-muted-foreground">{r.role}</div>
                </div>
                <div className="flex">
                  {[...Array(5)].map((_, i) => <Star key={i} className="h-3.5 w-3.5 fill-yellow-400 text-yellow-400" />)}
                </div>
              </div>
            </div>
          ))}
        </div>
      </Section>

      <Section eyebrow="Video stories">
        <div className="grid gap-6 md:grid-cols-3">
          {[1,2,3].map((i) => (
            <div key={i} className="glass rounded-3xl p-3 hover-lift">
              <div className="relative aspect-video overflow-hidden rounded-2xl bg-[image:var(--gradient-hero)]">
                <button className="absolute inset-0 m-auto grid h-16 w-16 place-items-center rounded-full bg-white/90 text-primary shadow-xl" aria-label="Play video">
                  <Play className="h-6 w-6 fill-primary" />
                </button>
              </div>
              <div className="p-3">
                <div className="font-semibold">Patient story #{i}</div>
                <div className="text-xs text-muted-foreground">2 min · transformation journey</div>
              </div>
            </div>
          ))}
        </div>
      </Section>
    </>
  );
}
