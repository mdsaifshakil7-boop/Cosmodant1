import { createFileRoute, Link } from "@tanstack/react-router";
import { Section, PageHero } from "@/components/site/Section";
import { Sparkles, Scissors, Zap, Wand2, Check } from "lucide-react";

export const Route = createFileRoute("/services")({
  head: () => ({
    meta: [
      { title: "Services — Skin, Hair, Laser & Aesthetic Treatments | Cosmodent" },
      { name: "description", content: "Explore Cosmodent's full menu of skin, hair, laser & aesthetic treatments — Botox, fillers, PRP, hydra facial, laser hair removal & more." },
      { property: "og:title", content: "Services | Cosmodent Aesthetic Clinic" },
      { property: "og:url", content: "/services" },
    ],
    links: [{ rel: "canonical", href: "/services" }],
  }),
  component: ServicesPage,
});

const groups = [
  {
    icon: Sparkles, title: "Skin Treatments", color: "from-pink-400 to-fuchsia-500",
    items: ["Acne treatment", "Pigmentation", "Skin whitening", "Anti-aging", "Dark circles"],
  },
  {
    icon: Scissors, title: "Hair Treatments", color: "from-purple-400 to-pink-500",
    items: ["Hair fall treatment", "PRP therapy", "Hair regrowth"],
  },
  {
    icon: Zap, title: "Laser Treatments", color: "from-fuchsia-500 to-purple-600",
    items: ["Laser hair removal", "Tattoo removal", "Skin rejuvenation"],
  },
  {
    icon: Wand2, title: "Aesthetic Treatments", color: "from-pink-500 to-purple-500",
    items: ["Botox", "Fillers", "Thread lift", "Skin tightening", "Hydra facial", "Carbon facial"],
  },
];

function ServicesPage() {
  return (
    <>
      <PageHero eyebrow="Services" title="A treatment for every story" subtitle="Medical-grade protocols crafted to celebrate your unique features." />

      <Section>
        <div className="grid gap-6 md:grid-cols-2">
          {groups.map((g) => (
            <div key={g.title} className="glass rounded-3xl p-6 hover-lift">
              <div className="flex items-center gap-4">
                <span className={`grid h-14 w-14 place-items-center rounded-2xl bg-gradient-to-br ${g.color} text-white shadow-[var(--shadow-soft)]`}>
                  <g.icon className="h-6 w-6" />
                </span>
                <h3 className="font-display text-2xl font-bold">{g.title}</h3>
              </div>
              <ul className="mt-6 space-y-3">
                {g.items.map((it) => (
                  <li key={it} className="flex items-center gap-3 rounded-xl bg-white/50 p-3">
                    <span className="grid h-7 w-7 place-items-center rounded-full bg-[image:var(--gradient-primary)] text-white">
                      <Check className="h-3.5 w-3.5" />
                    </span>
                    <span className="font-medium">{it}</span>
                  </li>
                ))}
              </ul>
              <Link to="/appointment" className="mt-6 inline-flex rounded-full btn-hero px-5 py-2.5 text-sm font-semibold">
                Book Consultation
              </Link>
            </div>
          ))}
        </div>
      </Section>

      <Section>
        <div className="relative overflow-hidden rounded-3xl bg-[image:var(--gradient-hero)] p-8 text-center text-white sm:p-14">
          <h3 className="font-display text-3xl font-bold sm:text-4xl">Not sure where to start?</h3>
          <p className="mx-auto mt-3 max-w-xl text-white/90">Take a free 15-minute consultation — we'll map a plan tailored to your skin & lifestyle.</p>
          <Link to="/appointment" className="mt-6 inline-flex rounded-full bg-white px-6 py-3 text-sm font-semibold text-primary hover-lift">
            Reserve Now
          </Link>
        </div>
      </Section>
    </>
  );
}
